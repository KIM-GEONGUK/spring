package member.Service;

public interface ChangePasswordService {
	public void changePassword(String email, String oldPassword, String newPassword);
}
