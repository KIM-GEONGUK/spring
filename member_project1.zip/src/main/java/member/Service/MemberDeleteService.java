package member.Service;

public interface MemberDeleteService {
	public void deleteMember(String email);
	
}
