package member.Service;

import member.Dto.MemberVo;

public interface MemberPrinterService {
	public void print(MemberVo member);
}
