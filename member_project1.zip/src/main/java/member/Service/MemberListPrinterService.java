package member.Service;

public interface MemberListPrinterService {
	public void printAll();
}
