package member.Service;

import member.Dto.RegisterRequest;

public interface MemberRegisterService {
	//등록 서비스 메서드
	public void regist(RegisterRequest req);
	
}
