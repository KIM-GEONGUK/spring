package Service;

import Dto.MemberVo;

public interface MemberPrinterService {
	//한사람의 정보 출력 메서드
	public void print (MemberVo member);
}
