package Service;

public interface MemberListPrinterService {
	public void printAll();
	//전체 목록 출력
}
