package Service;

public interface DeleteService {
	public void removeMember(String email);
	
	
}
